package cn.tedu.submarine;

import javax.swing.*;
import java.awt.*;

/*  战舰  */
public class Battleship extends SeaObject {
    private int life;
    public Battleship(){
        super(66,26,270,124,20);
        life = 5;
    }
    public void move(){
        //暂时搁置
    }
    public ImageIcon getImage(){
        return Images.battleship;//返回战舰图片
    }
}

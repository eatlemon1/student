package cn.tedu.submarine;

import javax.swing.*;

//深水炸弹
public class Bomb extends SeaObject{
    public Bomb(int x,int y){
        super(9,12,x,y,3);
    }
    public void move(){
        y+=speed;//y+(向y上)
    }
    public ImageIcon getImage(){
        return Images.bomb;
    }
}

package cn.tedu.submarine;
import javax.swing.ImageIcon;
import javax.swing.*;

//图片类
public class Images {
    //公开的 静态的  图片数据类型 变量名
    public static ImageIcon battleship;  //战舰图
    public static ImageIcon obsersubm;  //侦察潜艇图
    public static ImageIcon torpesubm;  //鱼雷潜艇图
    public static ImageIcon minesubm;  //水雷潜艇图
    public static ImageIcon mine;      //水雷图
    public static ImageIcon bomb;     //深水炸弹图
    public static ImageIcon sea;      //海洋图
    public static ImageIcon gameover; //游戏结束图
    static {//初始化静态图片
        battleship = new ImageIcon("img/battleship.jpg");
        obsersubm = new ImageIcon("img/obsersubm.jpg");
        torpesubm = new ImageIcon("img/torpesubm.png");
        minesubm = new ImageIcon("img/minesubm.png");
        mine = new ImageIcon("img/mine.jpg");
        bomb = new ImageIcon("img/bomb.png");
        sea = new ImageIcon("img/sea.jpg");
        gameover = new ImageIcon("img/gameover.jpg");
    }

    public static void main(String[] args) {//测试图片获取正常与否
        System.out.println(battleship.getImageLoadStatus());
        System.out.println(obsersubm.getImageLoadStatus());
        System.out.println(torpesubm.getImageLoadStatus());
        System.out.println(minesubm.getImageLoadStatus());
        System.out.println(mine.getImageLoadStatus());
        System.out.println(bomb.getImageLoadStatus());
        System.out.println(sea.getImageLoadStatus());
        System.out.println(gameover.getImageLoadStatus());

    }
}
package cn.tedu.submarine;

import javax.swing.*;

//水雷
public class Mine extends SeaObject{
    public Mine(int x,int y){

        super(11,11,x,y,1);
    }
    public void move(){
        y-=speed;//y+(向y下)
    }
    public ImageIcon getImage(){
        return Images.mine;
    }
}

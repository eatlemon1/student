package cn.tedu.submarine;

import javax.swing.*;
import java.util.Random;

//水雷潜艇移动
public class MineSubmarine extends SeaObject{
    public MineSubmarine(){
        super(63,19);
    }
    public void move(){
        x+=speed;//x+(向右)
    }
    public ImageIcon getImage(){
        return Images.minesubm;
    }
    public Mine shootMine(){
        int x = this.x+this.width;//x:水雷潜艇的x+水雷潜艇的宽
        int y = this.y-5;          //y:水雷潜艇的y-固定的5
        return new Mine(x,y);     //返回水雷对象
    }
}

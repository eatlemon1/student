package cn.tedu.submarine;

import javax.swing.*;
import java.util.Random;

//侦察潜艇移动
public class ObserveSubmarine extends SeaObject {
    public ObserveSubmarine(){
        super(63,19);
    }
    public void move(){
        x+=speed;//x+(向右)
    }
    public ImageIcon getImage(){
        return Images.obsersubm;//返回战舰图片
    }
}


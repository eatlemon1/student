package cn.tedu.submarine;
import javax.swing.ImageIcon;
import java.util.Random;
import java.awt.Graphics;
/*

*/
public abstract class SeaObject {
    public static final int LIVE = 0;
    public static final int DEAD = 1;
    protected int state = LIVE;//当前转改（默认为活）
    protected int width;
    protected int height;
    protected int x;
    protected int y;
    protected int speed;
    public SeaObject(int width, int height){
        Random r = new Random();
        this.width = width;
        this.height = height;
        x = -width;//负的潜艇的宽
        y = r.nextInt(World.HEIGHT-height-150+1)+150;
        speed = r.nextInt(3)+1;
    }
    public SeaObject(int width,int height,int x, int y,int speed){
        this.width = width;
        this.height = height;
        this.x = x;
        this.y = y;
        this.speed = speed;
    }
    public abstract void move();//海洋对象移动
    public abstract ImageIcon getImage();//调取图片
    public boolean isLive(){
        return state ==LIVE;//若当前状态为LIVE，则返回true表示活着的，否则返回false
    }
    public boolean isDead(){
        return state == DEAD;//若当前状态为DEAD，则返回true表示死了，否则返回false
    }
    public void paintImage(Graphics g){
        if(this.isLive()){
            this.getImage().paintIcon(null,g,this.x,this.y);
        }
    }

}

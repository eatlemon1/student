package cn.tedu.submarine;

import javax.swing.*;
import java.util.Random;

//鱼雷潜艇
public class TorpedoSubmarine extends SeaObject{
    public TorpedoSubmarine(){
        super(64,20);
    }
    public void move(){
        x+=speed;//x+(向右)
    }
    public ImageIcon getImage(){
        return Images.torpesubm;
    }
}
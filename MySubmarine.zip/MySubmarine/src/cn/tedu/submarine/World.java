package cn.tedu.submarine;
import javax.swing.*;
import java.awt.*;
import java.beans.PropertyVetoException;
import java.lang.reflect.Array;
import java.util.*;
import java.util.Timer;
import java.util.Arrays;

//整个游戏世界
public class World extends JPanel{//2.
    public static final int WIDTH = 641;//窗口的宽
    public static final int HEIGHT = 479;//窗口的高
    private Battleship ship = new Battleship();//战舰
    private SeaObject[] submarines ={};//潜艇（侦查，鱼雷，水雷）
    private Mine[] mines = {};//水雷
    private Bomb[] bombs = {};//炸弹
    //重写paint（）画 g:画笔
    public void paint(Graphics g){
        Images.sea.paintIcon(null,g,0,0);
        ship.paintImage(g);
        for(int  i = 0;i<submarines.length;i++){
            submarines[i].paintImage(g);
        }
        for(int i = 0;i<mines.length;i++){
            mines[i].paintImage(g);
        }
        for(int i = 0;i<bombs.length;i++){
            bombs[i].paintImage(g);
        }
    }
    //生成潜艇（侦查，水雷，鱼雷）对象
    public SeaObject nextSubmarine(){
        Random rand = new Random();//随机数对象
        int type = rand.nextInt(20);//0到19的随机数
        if(type<10){//0到9时，返回侦察潜艇
            return new ObserveSubmarine();
        }else if(type<15){//10到14时，返回鱼雷潜艇
            return new ObserveSubmarine();
        }else {//15-19时，返回水雷潜艇
            return new MineSubmarine();
        }
    }
    private int subEnterIndex = 0;
    //潜艇（侦查，水雷，鱼雷）入场
    public void submarinesEnterAction(){//每10毫秒走一次
        subEnterIndex++;//每10毫秒自增1
        if(subEnterIndex%40==0){//每400（40*10）毫秒走一次
            SeaObject obj = nextSubmarine();//获取潜艇对象
            submarines = Arrays.copyOf(submarines,submarines.length+1);
            submarines[submarines.length-1] = obj;
        }
    }
    private int mineEnterIndex = 0;
    public void mineEnterAction(){
        mineEnterIndex++;
        if(mineEnterIndex%100 == 0){
             //1秒走一次
            //代码暂时搁置
        }
    }

    public void moveAction(){//每10毫秒走一次
        for(int i = 0;i<submarines.length;i++){
            submarines[i].move();//潜艇移动
        }
        for(int i = 0;i<mines.length;i++){
            mines[i].move();//水雷移动
        }
        for(int i = 0;i<bombs.length;i++){
            bombs[i].move();
        }

    }

    public void action(){//启动程序的执行
        Timer timer = new Timer();//定时器对象
        int interval = 10;//定时间隔（毫秒为单位）
        timer.schedule(new TimerTask() {
            public void run() {//定时干的事（每10毫秒自动执行）
                submarinesEnterAction();//潜艇入场
                mineEnterAction();      //水雷入场
                moveAction();          //海洋对象移动
                repaint();             //重画（重新调用paint()方法）---不要求掌握
            }
        }, interval, interval);//定时任务
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame();//3.
        World world = new World();
        world.setFocusable(true);
        frame.add(world);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(WIDTH+16,HEIGHT+39);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);//1.设置窗口可见 2.尽快调用paint()方法
        world.action();//启动程序的执行
    }
}
/*1.获取图片，每个图片都需要获取 所以写在超类里面 但是每个照片的格式不同 所以用抽象方法
2.派生类重写获取图片
3.活着的目标才需要画出来 所以定义一个LIVE和DEAD常量 在定义一个表示状态的state变量 每个图片都要判断 所以这是个共有行为，所以设计在超类中，并且
判断是否为存活的方法一样，所以方法为普通方法
设计出isLive isDead表示目标是否存活
4.当以上数据准备就绪就可以画了，每个画的方法相同所以是普通方法
5.画像的行为做好了，World调用就行了
准备对象
paint方法重写---调用paintImage
 */